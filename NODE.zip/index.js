const express = require('express');
const app = express();
const port = process.env.PORT || 4000;



const data = [
    {
        name:"mani",
        age:23,
        status: "Active" 
    }
]
app.get('*', (req, res) => {
    res.send(data)
});


app.listen(port, () => console.log(`listening on http://localhost:${port}`));
